


const Product = () => {
    return (
        <p>I AM PRODUCT</p>
    )
}

export default Product;